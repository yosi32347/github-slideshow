<?php 
// לשים את הטוקן של הבוט
define('API_KEY','~TOKEN~');

// שימו את האיידי של הבוט
define('BOT_ID','~BOT_ID~');

// שימו את האיידי שלכם
define('YOUR_ID','~YOUR_ID~');

//define('api.telegram.org','149.154.167.199');

$update = json_decode(file_get_contents('php://input'),TRUE);
WriteToFile(json_encode($update));
{
$chatId = $update["message"]["from"]["id"];
$chatIdD = $update["message"]["chat"]["id"];
$chatusernameD = $update["message"]["chat"]["username"];
$firstName = $update["message"]["from"]["first_name"];
$lastName = $update["message"]["from"]["last_name"];
$userName = $update["message"]["from"]["username"];
$message = $update["message"]["text"];
$message_id = $update["message"]["message_id"];

$flchatId = $update["message"]["forward_from"]["id"];
$flfirstName = $update["message"]["forward_from"]["first_name"];
$fllastName = $update["message"]["forward_from"]["last_name"];
$fluserName = $update["message"]["forward_from"]["username"];
$flDate = $update["message"]["forward_date"];

$fChatId = $update["message"]["forward_from_chat"]["id"];
$fChatName = $update["message"]["forward_from_chat"]["title"];
$fChatUsername = $update["message"]["forward_from_chat"]["username"];
$fChatMsgId = $update["message"]["forward_from_message_id"];
$fChatDate = $update["message"]["forward_date"];

$entitiesId = $update["message"]["entities"][0]["user"]["id"];
$entitiesFirstName = $update["message"]["entities"][0]["user"]["first_name"];
$entitiesLastName = $update["message"]["entities"][0]["user"]["last_name"];
$entitiesUserName = $update["message"]["entities"][0]["user"]["username"];

$newChatToGroupId = $update["message"]["new_chat_member"]["id"];
$ChatName = $update["message"]["chat"]["title"];

$inId = $update["inline_query"]["id"];
$inChatId = $update["inline_query"]["from"]["id"];
$inFirstName = $update["inline_query"]["from"]["first_name"];
$inLastName = $update["inline_query"]["from"]["last_name"];
$inUserName = $update["inline_query"]["from"]["username"];
$inString = $update["inline_query"]["query"];

$QueryId = $update["callback_query"]["id"];
$QchatId = $update["callback_query"]["from"]["id"];
$QFirstName = $update["callback_query"]["from"]["first_name"];
$QLastName = $update["callback_query"]["from"]["last_name"];
$QUserName = $update["callback_query"]["from"]["username"];
$Qmessage = $update["callback_query"]["message"]["text"];
$Qmessage_id = $update["callback_query"]["message"]["message_id"];
$Qchat_instance = $update["callback_query"]["chat_instance"];
$Qdata = $update["callback_query"]["data"];
}


// if (!is_null($chatId)){
//	 CheckId($chatId);
// }
    $remove_keyboard = json_encode(array('remove_keyboard' => true));

if ($chatId == YOUR_ID) {
	$reply_markup = json_encode(array(
        'keyboard' => array(array("כמה משתמשים יש?"),array("פרטים על מישהו אחר", "הפרטים שלי"),array("פרטים על קבוצה", "פרטים על ערוץ") ,array("👾 לכל הבוטים שלי 👾")),
		'one_time_keyboard' => false,
		'resize_keyboard' => true
		)); 
} else {
	$reply_markup = json_encode(array(
        'keyboard' => array(array("פרטים על מישהו אחר", "הפרטים שלי"),array("פרטים על קבוצה", "פרטים על ערוץ") ,array("👾 לכל הבוטים שלי 👾")),
		'one_time_keyboard' => false,
		'resize_keyboard' => true
		));
}
{
    $reply_markupInline = json_encode(array(
        'inline_keyboard' => array(array(array('url'  => "https://telegram.me/share/url?url=https://t.me/ShowIDBot" , 
                       'text' => "שתף בוט")))
    ));

    $reply_markupInline_start = json_encode(array(
        'inline_keyboard' => array(array(array(	'callback_data'  => "עברית" , 
                                                'text' => "עברית 🇮🇱"),
                                         array('callback_data'  => "אנגלית" , 
                                                'text' => "English 🇱🇷")))
    ));
}
if ((GetLang($chatId) == "עברית") || (GetLang($QchatId) == "עברית")) {
    {
    // שפה
    {
        $LangChangeText = "שנה שפה 💬";

    
        $reply_markupInline_lang = json_encode(array(
			'inline_keyboard' => array(array(array(	'callback_data'  => "שינוי שפה" , 
													'text' => $LangChangeText)),
									   array(array('callback_data'  => "תפריט" , 
													'text' => "תפריט 📌")))
		));
    }
    
    // תפריט
    {$reply_markupInline_menu = json_encode(array(
    'inline_keyboard' => array(	array(array('callback_data'  => "הפרטים שלי" , 
                                            'text' => "הפרטים שלי 👤")),
                                array(array('callback_data'  => "מישהו אחר" , 
                                            'text' => "פרטים על מישהו 🕵")),
                                array(array('callback_data'  => "קבוצה" , 
                                            'text' => "פרטים על קבוצה 👥")),
                                array(array('callback_data'  => "ערוץ" , 
                                            'text' => "פרטים על ערוץ 📢")),
                                array(array('callback_data'  => "עוד" , 
                                            'text' => "עוד ⚙")))
    ));

    $MenubtnText = "תפריט 📌";
    $MenuText = "תפריט - בחר אחת מהאפשרויות: ";
    }
    
    // הפרטים שלי
    {
        $IdText = "ה-ID שלך: ";
        $NameText = "השם שלך: ";
        $UserText = "היוזר שלך: @";
    }

    // פרטים על מישהו אחר
    {
        $SomeOneText = "פשוט העבירו הודעה ממי שברצונכם לדעת את הפרטים.\nישנה אפשרות גם להעביר הודעה מתיוג בקבוצה למשתמש בלי שם משתמש.";
    
        $SomeOneIdText = "ה-ID שלו: ";
    
        $SomeOneNameText = "שם: ";
    
        $SomeOneUserText = "יוזר: ";
    
        $SomeOneSharetext = "\n           לעוד מידע היכנסו 👆\n\n👇הפרטים על האיש שביקשתם 👇\n";
    
        $SomeOneShareBtntext = "שתף פרטים";
    
        $SomeOneDate = "נשלח ב: ";
    
        $lastupdateText = "נראה לאחרונה ב: ";
    
        $typeText = "סוג: ";
    
        $aboutText = "אודות: ";
    }

    // קבוצה
    {
        $GroupText = "הוסיפו אותי לקבוצה ואני אשלח לכם את הפרטים על הקבוצה.\n(הבוט יוצא אוטמטית מהקבוצה.)";
    
        $GroupinfoText = "פרטי הקבוצה: 👥";
            
        $GroupIdText = "ה-ID של הקבוצה: ";

        $GroupNameText = "שם הקבוצה: ";
    
        $GroupUserText = "יוזר קבוצה: @";
        
        $GroupMngText = "פרטי מנהל: 👤";
    
        $GroupTextDesc =  "מידע ID - הבוט שיביא לכם מידע על משתמשים בטלגרם - 🆔 @ShowIDBot. 🆔";
    }

    // ערוץ
    {
        $ChannelText = "העבירו הודעה מהערוץ שברצונכם לקבל את הפרטים.\nבמידה והערוץ ציבורי ישלח לכם קישור לערוץ וקישור לפוסט.";
    
        $ChannelShareText = "קישור לערוץ";
            
        $ChannelPostText = "קישור לפוסט";
    }
    
    // עוד
    {
        $MoreInline = json_encode(array(
    'inline_keyboard' => array(	array(array('callback_data'  => "שינוי שפה" , 
								            'text' => $LangChangeText)),
                                array(array('callback_data'  => "תפריט", 
                                            'text' => $MenubtnText)))
            ));
        $MoreText = "אפשרויות - בחר אחת מהאפשרויות:";
    }
    
    // ברירית מחדל
    {
        $DefaultText = "בוט זה נוצר ע''י @mugavri.\nלהערות והארות ולהצעות לשיפור הבוט פנו אלי 😉.";

    }
    }
} else {
    {
    // Lang
    {
        $LangChangeText = "Change Language 💬";
    
		$reply_markupInline_lang = json_encode(array(
        'inline_keyboard' => array(array(array(	'callback_data'  => "שינוי שפה" , 
												'text' => $LangChangeText)),
									array(array(	'callback_data'  => "תפריט" , 
												'text' => "Menu 📌")))
		));    
    }
    
    // menu
    {
    $reply_markupInline_menu = json_encode(array(
    'inline_keyboard' => array(	array(array('callback_data'  => "הפרטים שלי" , 
                                            'text' => "Info about me 👤")),
                                array(array('callback_data'  => "מישהו אחר" , 
                                            'text' => "Info about someone 🕵")),
                                array(array('callback_data'  => "קבוצה" , 
                                            'text' => "Info about Group 👥")),
                                array(array('callback_data'  => "ערוץ" , 
                                            'text' => "Info about Channel 📢")),
                                array(array('callback_data'  => "עוד" , 
                                            'text' => "More ⚙")))
    ));

    $MenubtnText = "Menu 📌";
    $MenuText = "Menu - Select one of the options:";
    }

    // my info
    {
        $IdText = "Your ID: ";
        $NameText = "Your Name: ";
        $UserText = "Your Username: @";
    }

    // someone Info
    {
        $SomeOneText = "Just forward a message from who you want to know the Info.\nthere's the option to also forward a message Tag group to a user without a username.";
    
        $SomeOneIdText = "ID: ";
    
        $SomeOneNameText = "Name: ";
    
        $SomeOneUserText = "Username: ";
    
        $SomeOneSharetext = "\nFor more info press 👆\n\n👇 Info about the user: 👇\n";

        $SomeOneShareBtntext = "Share info";
    
        $SomeOneDate = "Send at: ";
        
        $lastupdateText = "Last seen: ";
    
        $typeText = "Type: ";
    
        $aboutText = "About: ";

    }

    // group
    {
        $GroupText = "Add me to the group and I'll send you the Info About the group.\n(the bot comes out automatically from the group.)";
    
        $GroupinfoText = "Group info: 👥";
            
        $GroupIdText = "Group ID: ";
            
        $GroupNameText = "Group name: ";
    
        $GroupUserText = "Group username: @";
    
        $GroupMngText = "Manager info: 👤";
    
        $GroupTextDesc = "Info ID - The bot that bring you information about telegram users - 🆔 @ShowIDBot. 🆔";
    } 

    // Channel
    {
        $ChannelText = "Forward a message from the channel that you want to get the Info.\nIf the Channel is Public than I will send you a link to Channel and a link to the post.";
    
        $ChannelShareText = "Link to Channel";
            
        $ChannelPostText = "Link to Post";
    }
    
    // More
    {
        $MoreText = "Option - Select one of the options:";
        $MoreInline = json_encode(array(
            'inline_keyboard' => array(	array(array('callback_data'  => "שינוי שפה" , 
                                                    'text' => $LangChangeText)),
                                        array(array('callback_data'  => "תפריט", 
                                                    'text' => $MenubtnText)))
            ));
    }
    
    // Default
    {
        $DefaultText = "This bot create by @mugavri.\nFor glitches and suggestions to improve the bot connect me 😉.";
    }
    }
}


// Send to bot mmessage with "/start"
if(preg_match('/^\/(start)/',$message,$match)) {
    {
	if ($message == "/start") {
		 if (CreatNewUser($chatId)) {
			$postData = array (
				'chat_id' => $chatId,
				'text' => "_ברוכים הבאים_, בחרו את *השפה* שלכם:\n\n_Welcome_, please select your *language*:",
				'parse_mode' => 'Markdown',
				'reply_markup' => $reply_markupInline_start
				// 'reply_to_message_id' => $message_id
			);
		 } else {
			 $postData = array (
				 'chat_id' => $chatId,
			     'text' => "_".$MenuText."_",
				 'parse_mode' => 'Markdown',
				 'reply_markup' => $reply_markupInline_menu
				 // 'reply_to_message_id' => $message_id
			 );
		 }
		makehttpreqeust('sendMessage', $postData);
		
	}
    }
}elseif(!is_null($entitiesId)){
    {
        date_default_timezone_set('Asia/Jerusalem');

        $time = date("Y-m-d H:i:s", $flDate);
    
        $postData = array (
			'user_id' => $entitiesId,
			'limit' => 1
		);
        $upd = makehttpreqeust('getUserProfilePhotos',$postData);	
        
	    $picId = $upd["result"]["photos"][0][0]["file_id"];
    
        $update = GetLastUpdate($entitiesId);
        $lastupdate = date("Y-m-d H:i:s", $update["result"]["last_update"]);
        $type = $update["result"]["type"];
        $about = $update["result"]["about"];
    
		$text = $SomeOneIdText.$entitiesId.".\n".$SomeOneNameText.$entitiesFirstName;
		if (!is_null($entitiesLastName)) {
			$text = $text." ".$entitiesLastName.".";
		} else{
			$text = $text.".";
		}
		if (!is_null($entitiesUserName)){
			$text = $text."\n".$SomeOneUserText.$entitiesUserName.".";
		}
        if (!is_null($type)) {
            if (GetLang($chatId) == "עברית") {
                $type = "יוזר";
            }
			$text = $text."\n".$typeText.$type.".";
        }
        if (!is_null($about)) {
			$text = $text."\n".$aboutText.$about.".";
        }
        if (!is_null($update["result"]["last_update"])) {
			$text = $text."\n".$lastupdateText.$lastupdate.".";
        }
            $text = $text."\n".$SomeOneDate.$time.".";

		$out = urlencode($SomeOneSharetext.$text);
		$out = str_replace('+','%20',$out); 

		$reply_markupInline = json_encode(array(
		'inline_keyboard' => array( array(array('url'  => "https://t.me/share/url?url=https://t.me/ShowIDBot".$out, 
                                                'text' => $SomeOneShareBtntext)),
                                    array(array('callback_data'  => "תפריט חדש", 
                                                'text' => $MenubtnText)))
		));
		
    if (is_null($picId)){
		$postData = array (
			'chat_id' => $chatId,
			'text' => $text,
			'reply_markup' => $reply_markupInline,
			'reply_to_message_id' => $message_id
		);
		makehttpreqeust('sendMessage',$postData);		
		
	}else{
		$postData = array (
			'chat_id' => $chatId,
			'photo' => $picId,
//			'caption' => $text,
//			'reply_markup' => $reply_markupInline,
			'reply_to_message_id' => $message_id
			);
		makehttpreqeust('sendPhoto',$postData);
        $postData = array (
			'chat_id' => $chatId,
			'text' => $text,
			'parse_mode' => "HTML",
			'reply_markup' => $reply_markupInline,
//			'reply_to_message_id' => $message_id
			);
		makehttpreqeust('sendMessage',$postData);
	}
    }
} elseif(!is_null($fChatId)) {
    {
    date_default_timezone_set('Asia/Jerusalem');

    $time = date("Y-m-d H:i:s", $fChatDate);
    
    $text = $SomeOneIdText.$fChatId.".\n".$SomeOneNameText.$fChatName.".";
    $text = $text."\n".$SomeOneDate.$time.".";
    
    if (!is_null($fChatUsername))
    {
        $url = "https://t.me/".$fChatUsername."/".$fChatMsgId;
        
        $text = $text."\n".$SomeOneUserText." @".$fChatUsername.".";
        $text = $text."\n".$ChannelPostText.": ".$url.".";
        
        $out = urlencode($SomeOneSharetext.$text);
		$out = str_replace('+','%20',$out); 
        
        $reply_markupInline = json_encode(array(
        'inline_keyboard' => array( array(array('url'  => "https://telegram.me/share/url?url=https://t.me/ShowIDBot".$out, 
                                                'text' => $SomeOneShareBtntext)),
                                    array(array('url'  => "https://t.me/".$fChatUsername, 
                                                'text' => $ChannelShareText),
                                          array('url'  => $url, 
                                                'text' => $ChannelPostText)),
                                    array(array('callback_data'  => "תפריט חדש", 
                                                'text' => $MenubtnText)))
        ));
    } else {
        $out = urlencode($SomeOneSharetext.$text);
		$out = str_replace('+','%20',$out); 
        
        $reply_markupInline = json_encode(array(
        'inline_keyboard' => array( array(array('url'  => "https://t.me/share/url?url=https://t.me/ShowIDBot".$out, 
                                                'text' => $SomeOneShareBtntext)),
                                    array(array('callback_data'  => "תפריט חדש", 
                                                'text' => $MenubtnText)))
        ));
    }

    $out = urlencode($SomeOneSharetext.$text);
    $out = str_replace('+','%20',$out); 

    $postData = array (
        'chat_id' => $chatId,
        // 'parse_mode' => 'Markdown',
        'text' => $text,
        'reply_markup' => $reply_markupInline,
        'disable_web_page_preview' => true,
        'reply_to_message_id' => $message_id
        );
     makehttpreqeust('sendMessage',$postData);
    }
} elseif(!is_null($flchatId)){
    {
    
    date_default_timezone_set('Asia/Jerusalem');

    $time = date("Y-m-d H:i:s", $flDate);
    
    $postData = array (
			'user_id' => $flchatId,
			'limit' => 1
    );
    $upd = makehttpreqeust('getUserProfilePhotos',$postData);	
    
	$picId = $upd["result"]["photos"][0][0]["file_id"];

//    $update = GetLastUpdate($flchatId);
    $lastupdate = date("Y-m-d H:i:s", $update["result"]["last_update"]);
    $type = $update["result"]["type"];
    $about = $update["result"]["about"];
    
    $text = "<i>".$SomeOneIdText."</i><b>".$flchatId.".</b>\n<i>".$SomeOneNameText."</i><b>".$flfirstName;

    if (!is_null($fllastName)){
        $text = $text." ".$fllastName.".</b>";
    } else{
        $text = $text."</b>.";
    }
    if (!is_null($fluserName)){
        $text = $text."\n<i>".$SomeOneUserText."</i>@".$fluserName.".";
    }
    if (!is_null($type)) {
        if (GetLang($chatId) == "עברית") { 
            if($type == "user") {
                $type = "יוזר";
            } elseif ($type == "bot") {
                $type = "בוט";
            }
        } 
        $text = $text."\n<i>".$typeText."</i><b>".$type.".</b>";
    }
    if (!is_null($about)) {
	   $text = $text."\n<i>".$aboutText."</i><b>".$about.".</b>";
    }
    if (!is_null($update["result"]["last_update"])) {
		$text = $text."\n<i>".$lastupdateText."</i><b>".$lastupdate.".</b>";  
    }
    $text = $text."\n<i>".$SomeOneDate."</i><b>".$time.".</b>";
    
    $out = urlencode($SomeOneSharetext.$text);
    $out = str_replace('+','%20',$out); 

    $reply_markupInline = json_encode(array(
    'inline_keyboard' => array(array(array( 'url'  => "https://telegram.me/share/url?url=https://t.me/ShowIDBot".$out, 
                                            'text' => $SomeOneShareBtntext)),
                               array(array( 'callback_data'  => "תפריט חדש", 
                                            'text' => $MenubtnText)))
    ));

    if (is_null($picId)){
		$postData = array (
			'chat_id' => $chatId,
			'text' => $text,
            'parse_mode' => "HTML",
			'reply_markup' => $reply_markupInline,
			'reply_to_message_id' => $message_id
		);
		makehttpreqeust('sendMessage',$postData);		
		
	}else{
		$postData = array (
			'chat_id' => $chatId,
			'photo' => $picId,
//			'caption' => $text,
//			'reply_markup' => $reply_markupInline,
			'reply_to_message_id' => $message_id
			);
		makehttpreqeust('sendPhoto',$postData);
        
        $postData = array (
			'chat_id' => $chatId,
			'text' => $text,
			'parse_mode' => "HTML",
			'reply_markup' => $reply_markupInline,
//			'reply_to_message_id' => $message_id
			);
		makehttpreqeust('sendMessage',$postData);
			
	}
    
    }
} elseif($message == 'פרטים על מישהו אחר'){
    {
	$postData = array (
		'chat_id' => $chatId,
		'text' => "פשוט העבירו הודעה ממי שברצונכם לדעת את הפרטים.\nישנה אפשרות גם להעביר הודעה מתיוג בקבוצה למשתמש בלי שם משתמש.",
		'reply_markup' => $remove_keyboard,
		);
		
	makehttpreqeust('sendMessage',$postData);
    }
} elseif($message == 'הפרטים שלי'){
    {
    $postData = array (
			'user_id' => $chatId,
			'limit' => 1
		);
    $upd = makehttpreqeust('getUserProfilePhotos',$postData);	
    
	$picId = $upd["result"]["photos"][0][0]["file_id"];

	$text = "מספר הזיהוי שלך: ".$chatId.".\nהשם שלך: ".$firstName;

	if (!is_null($lastName)) {
			$text = $text." ".$lastName;
	}
	if (!is_null($userName)){			
			$text = $text.".\nהיוזר שלך: @".$userName.".";
	}
		
	$reply_markupInline = json_encode(array(
		'inline_keyboard' => array(	array(	array(	'switch_inline_query'  => "", 
													'text' => "שתף פרטים")))
	));
		
	if (is_null($picId)){
		$postData = array (
			'chat_id' => $chatId,
			'text' => $text,
			'reply_markup' => $remove_keyboard,
			'reply_to_message_id' => $message_id
		);
		makehttpreqeust('sendMessage',$postData);		
		
	}else{
		$postData = array (
			'chat_id' => $chatId,
			'photo' => $picId,
			'caption' => $text,
			'reply_markup' => $remove_keyboard,
			'reply_to_message_id' => $message_id
			);
		makehttpreqeust('sendPhoto',$postData);
			
	}
    }
}elseif($chatId == YOUR_ID and $message == 'Do'){
    {
		// $reply_markupInline = json_encode(array(
		// 'inline_keyboard' => array(array(array('url'  => "https://telegram.me/share/url?url=@showidbot", 
        // 'text' => "שתף את הרובוט")), array(array('url'  => "https://telegram.me/OpenLinksBot", 
        // 'text' => "רובוט פתיחת קישורים")))
		// ));
	
	// SendToAllusers($reply_markupInline);
	
	$a =  MAKE();
	
	$postData = array (
		'chat_id' => YOUR_ID,
		'text' => $a
		);

	makehttpreqeust('sendMessage',$postData);
    }
} elseif ($chatId == YOUR_ID and $message == "?"){
    {
	$text = $text."*כמות משתמשים :* `".SumAllusers()."`";
	
	$postData = array (
		'chat_id' => $chatId,
		'text' => $text,
		'parse_mode' => 'Markdown',
		'reply_markup' => $remove_keyboard
		);

	makehttpreqeust('sendMessage',$postData);
    
//    $postData = array (
//		'chat_id' => $chatId,
//		'document' => "http://down.upfile.co.il/downloadnew/file/234649780/1a7e7202a5b16d2054424e35243d3ce6_ndp7F919881988wSi5kIsWx64S1Rw%3D%3D"
//		);
//
//	makehttpreqeust('sendDocument',$postData);
    sendDocument($chatId, "ShowId.php", "test");
//    	$postData = array (
//		'chat_id' => $chatId,
//		'document' => file_get_contents("https://mugavribot.esy.es/MyBots/ShowId/log.txt")
//		);
//    	makehttpreqeust('sendDocument',$postData);

    }
} elseif ($message == "👾 לכל הבוטים שלי 👾"){
    {
	$postData = array (
		'chat_id' => $chatId,
		'parse_mode' => 'Markdown',
		'text' => "[לערוץ עם כל המידע על רובוטים חדשים וקיימים שלי היכנסו:](https://t.me/MugavriBots)",
		'reply_markup' => $remove_keyboard
	);
	makehttpreqeust('sendMessage',$postData);
    }
} elseif ($message == "פרטים על קבוצה") {
    {
	$postData = array (
		'chat_id' => $chatId,
		'text' => "הוסיפו אותי לקבוצה ואני אשלח לכם את ה ID של הקבוצה. \n (הבוט יוצא אוטמטית מהקבוצה.)",
		'reply_markup' => $remove_keyboard
	);
	makehttpreqeust('sendMessage',$postData);
	}
} elseif ($message == "פרטים על ערוץ"){
    {
	$postData = array (
		'chat_id' => $chatId,
		'text' => "העבירו הודעה מהערוץ שברצונכם לקבל את הפרטים.\nבמידה והערוץ ציבורי ישלח לכם קישור לערוץ וקישור לפוסט.",
		'reply_markup' => $remove_keyboard
	);
	makehttpreqeust('sendMessage',$postData);
    }
}elseif ($newChatToGroupId == BOT_ID) {
    {
	$url = "https://api.telegram.org/bot".API_KEY."/getChatAdministrators?chat_id=".$chatIdD;
		
	$ch = curl_init();  
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    $res = curl_exec($ch);
    curl_close($ch);

    $UserIdIn = json_decode($res,TRUE);
	
	$bb = false;
	$e = 0;
	$AdminId 			= $UserIdIn["result"][$e]["user"]["id"];
	$Adminfirstname 	= $UserIdIn["result"][$e]["user"]["first_name"];
	$AdminLastName 		= $UserIdIn["result"][$e]["user"]["last_name"];
	$AdminUsername 		= $UserIdIn["result"][$e]["user"]["username"];
		
	while (!($bb)) {
		if ($UserIdIn["result"][$e]["status"] == "creator") {
			$AdminId 		= $UserIdIn["result"][$e]["user"]["id"];
			$Adminfirstname 	= $UserIdIn["result"][$e]["user"]["first_name"];
			$AdminLastName 		= $UserIdIn["result"][$e]["user"]["last_name"];
			$AdminUsername 		= $UserIdIn["result"][$e]["user"]["username"];
			$bb = true;
		}
		
		$e++;
		
		if ($e > 10) {
			$bb = true;
		}
	}	
    
    
	$text = $GroupinfoText."\n".$GroupIdText.$chatIdD.".";
	$text = $text."\n".$GroupNameText.$ChatName.".";
    
    if (!is_null($chatusernameD)) {
        	$text = $text."\n".$GroupUserText.$chatusernameD.".";
    }
    
	$text = $text."\n\n".$GroupMngText."\n".$SomeOneIdText.$AdminId.".\n".$SomeOneNameText.$Adminfirstname;

	if (!is_null($AdminLastName)) {
		$text = $text." ".$AdminLastName.".";
	} else{
		$text = $text.".";
	}
	if (!is_null($AdminUsername)) {
		$text = $text."\n".$SomeOneUserText.$AdminUsername.".";
	}
	
    $out = urlencode($SomeOneSharetext.$text);
    $out = str_replace('+','%20',$out); 

    $reply_markupInline = json_encode(array(
    'inline_keyboard' => array(array(array( 'url'  => "https://telegram.me/share/url?url=https://t.me/ShowIDBot".$out, 
                                            'text' => $SomeOneShareBtntext)),
                               array(array( 'callback_data'  => "תפריט חדש", 
                                            'text' => $MenubtnText)))
    ));
    
	$postData = array (
		'chat_id' => $chatId,
		'text' => $text,
		'reply_markup' => $reply_markupInline
	);
		
	makehttpreqeust('sendMessage',$postData);
    
	$postData = array (
		'chat_id' => $chatIdD,
		'text' => $GroupTextDesc,
		'reply_markup' => $remove_keyboard
	);
	makehttpreqeust('sendMessage',$postData);
			
			
	$url = "https://api.telegram.org/bot".API_KEY."/leaveChat?chat_id=".$chatIdD;

	httpGet($url);
    }
} elseif(!is_null($inId)) {
    {
    $postData = array (
			'user_id' => $inChatId,
			'limit' => 1
		);
    $upd = makehttpreqeust('getUserProfilePhotos',$postData);	
    
	$picId = $upd["result"]["photos"][0][0]["file_id"];
	$text = "מספר הזיהוי שלי: ".$inChatId.".\nהשם שלי: ".$inFirstName;

	if (!is_null($inLastName)) {
		$text = $text." ".$inLastName;
	} else{
		$text = $text.".";
	}
	if (!is_null($inUserName))
	{			
		$text = $text.".\nהיוזר שלי: @".$inUserName.".";
	}
	if (!($inString == ""))
	{
		$text = $text."\nפרטים עלי: ".$inString.".";
	}
	if(is_null($picId)) {
		$picId = "AgADBAAD46gxG8Un0FBOIVAGLfv71OQNoBkABNh3q9dru7Xt_04BAAEC";
	}
	
	$reply_markupInline = array(
		'inline_keyboard' => array(array(array(	'url'  => "https://telegram.me/showidbot", 
												'text' => "לעוד אפשרויות")),
									array(array('switch_inline_query_current_chat'  => "", 
												'text' => "שתף את הפרטים שלי")))
    );
	
	$r = array(
		'type' => 'photo',	
		'id' => '1',
		'photo_file_id' => $picId,
		'title' => 'test title',
		'description' => 'test description',
		'caption' => $text,
		'reply_markup' => $reply_markupInline
	);
		
	$postData = array (
		'inline_query_id' => $inId,
		'results' => json_encode(array($r)),
		'is_personal' => true,
		'cache_time' => 10,
		// 'switch_pm_text' => "true",
		// "switch_pm_parameter" => "test"
	);
	makehttpreqeust('answerInlineQuery',$postData);
    }
} elseif(!is_null($Qdata)){
    {
	if ($Qdata == "עברית") {
        {
		ChangeLang($QchatId, "עברית");
        
        $reply_markupInline_lang = json_encode(array(
			'inline_keyboard' => array(array(array(	'callback_data'  => "שינוי שפה" , 
													'text' => "שנה שפה 💬")),
									   array(array('callback_data'  => "תפריט" , 
													'text' => "תפריט 📌")))
		));
		$postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'parse_mode' => 'Markdown',
			'text' => "שפת הבוט נקבעה ל*עברית*!",
			'reply_markup' => $reply_markupInline_lang
		);
		makehttpreqeust('editMessageText', $postData, '');
        }
	} elseif ($Qdata == "אנגלית") {
        {
		ChangeLang($QchatId, "אנגלית");
        
		$reply_markupInline_lang = json_encode(array(
        'inline_keyboard' => array(array(array(	'callback_data'  => "שינוי שפה" , 
												'text' => "Change Language 💬")),
									array(array(	'callback_data'  => "תפריט" , 
												'text' => "Menu 📌")))
		));    
		$postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'parse_mode' => 'Markdown',
			'text' => "The bot language set to *English*!",
			'reply_markup' => $reply_markupInline_lang
		);
		makehttpreqeust('editMessageText', $postData, '');
        }
	} elseif ($Qdata == "שינוי שפה") {
        {
		$postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => "בחרו את *השפה* שלכם:\n\nPlease select your *language*:",
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_start
		);
		
		makehttpreqeust('editMessageText', $postData);
        }
	} elseif ($Qdata == "תפריט") {
        {
		$postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => "_".$MenuText."_",
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_menu
		);
		
		makehttpreqeust('editMessageText', $postData);
        }
	} elseif ($Qdata == "תפריט חדש") {
        {
		$postData = array (
			'chat_id' => $QchatId,
			'text' => "_".$MenuText."_",
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_menu
		);
		
		makehttpreqeust('sendMessage', $postData);
        }
	} elseif ($Qdata == "הפרטים שלי") {
        {
        
        $postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => "_".$MenuText."_",
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_menu
		);
		
		makehttpreqeust('editMessageText', $postData);
        
        $postData = array (
                'user_id' => $QchatId,
                'limit' => 1
        );
        $upd = makehttpreqeust('getUserProfilePhotos',$postData);	

        $picId = $upd["result"]["photos"][0][0]["file_id"];

        $text = $IdText.$QchatId.".\n".$NameText.$QFirstName;

        if (!is_null($QLastName)) {
            $text = $text." ".$QLastName;
        } else {
            $text = $text.".";
        }
        if (!is_null($QUserName)){			
                $text = $text.".\n".$UserText.$QUserName.".";
        }

        $reply_markupInline = json_encode(array(
            'inline_keyboard' => array(	array(array('switch_inline_query'  => "", 
                                                    'text' => $SomeOneShareBtntext)),
                                        array(array('callback_data'  => "תפריט חדש", 
                                                    'text' => $MenubtnText)))
        ));

        if (is_null($picId)){
            $postData = array (
                'chat_id' => $QchatId,
                'text' => $text,
                'reply_markup' => $reply_markupInline,
//                'reply_to_message_id' => $message_id
            );
            makehttpreqeust('sendMessage',$postData);		

        } else{
            $postData = array (
                'chat_id' => $QchatId,
                'photo' => $picId,
                'caption' => $text,
                'reply_markup' => $reply_markupInline,
//                'reply_to_message_id' => $message_id
                );
            makehttpreqeust('sendPhoto',$postData);
			
	    }
        }
    } elseif ($Qdata == "מישהו אחר") {
        {
        $postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => $SomeOneText,
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_menu
		);
		
		makehttpreqeust('editMessageText', $postData);
        }
    }elseif ($Qdata == "קבוצה") {
        {
        $postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => $GroupText,
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_menu
		);
		
		makehttpreqeust('editMessageText', $postData);
        }
    } elseif ($Qdata == "ערוץ") {
        {
         $postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => $ChannelText,
			'parse_mode' => 'Markdown',
			'reply_markup' => $reply_markupInline_menu
		);
		
		makehttpreqeust('editMessageText', $postData);
    }
    } elseif ($Qdata == "עוד") {
        {
        
        $postData = array (
			'chat_id' => $QchatId,
			'message_id' => $Qmessage_id,
			'text' => "_".$MoreText."_",
			'parse_mode' => 'Markdown',
			'reply_markup' => $MoreInline
		);
		
		makehttpreqeust('editMessageText', $postData);
        }
    }
	
	$postData = array (
		'callback_query_id' => $QueryId
		// 'text' => ""
		// 'show_alert' => 'true'
	);
	makehttpreqeust('answerCallbackQuery', $postData);
    }
} else{
    {
//    if ($chatId == 79612226) {
//            $t = "לא ערבית";
//
//        if(preg_match("/\p{Arabic}/u", $message)) {
//            $t = "ערבית";
//        } 
//        $postData = array (
//            'chat_id' => $chatId,
//            'text' => $t
//        );
//        makehttpreqeust('sendMessage', $postData);
//    } else {
    
        $DefaultInline = json_encode(array(
        'inline_keyboard' => array(array(array('callback_data'  => "תפריט", 
                                                'text' => $MenubtnText)))
        ));
        $postData = array (
            'chat_id' => $chatId,
            'text' => $DefaultText,
            'reply_markup' => $DefaultInline,
        );
        makehttpreqeust('sendMessage', $postData);
//    }
    }
}

function httpGet($url){
	
    $ch = curl_init();  
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    $output=curl_exec($ch);
    curl_close($ch);
    return json_decode($output,TRUE);
}

function makehttpreqeust($method,$datas=[]){
	
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
//    $url = "149.154.167.199/bot".API_KEY."/".$method;
    $ch = curl_init();
//    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//        "Content-Type:multipart/form-data"
//    ));
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
	//WriteToFile($res);
    
    if(curl_error($ch)){
//        WriteToFile("error: " . curl_error($ch));
        curl_close($ch);
    }else{
		curl_close($ch);
        return json_decode($res,TRUE);
    }
}

function WriteToFile($write){
	$myfile = fopen('log.txt', 'w');
	fwrite($myfile,$write);
//	fwrite($myfile,"\n\n");
	fclose($myfile);
}

function WriteChatID($write){
	$myfile = fopen('ChatID.txt', 'a');
	fwrite($myfile,$write);
	fwrite($myfile,"\n");
	fclose($myfile);
}

function CheckId($chatId){

	$tempid = file_get_contents('ChatID.txt');
	$pos1 = stripos($tempid, (string)$chatId);

	if ($pos1 === false) {
//		 WriteChatID($chatId);
		return true;
	} else {
		return false;
	}
}

function SendToAllusers($reply_markupInline){
	
	//$myfile = fopen('ChatID.txt', 'r');	
	for ($i = 0;$i < 341;$i++) {
		$contents = fgets($myfile, 20);
		//WriteToFile("contents:  ".$contents);
		
		$postData = array (
			'chat_id' => $contents,
			'text' => "חנוכה שמח!!\n\n📍 נוספה ברובוט אפשרות לראות את פרטי המנהל של קבוצה.\nפשוט הוסיפו את הבוט לקבוצה. (הבוט יוצא אוטמטית מהקבוצה.)\n\n📍 יש לכם רעיון לבוט? חושבים שהוא שימושי לכולם?\n🆔 פנו אלי... @mugavri.  🆔",
			'reply_markup' => $reply_markupInline,
		);
		makehttpreqeust('sendMessage', $postData);
	}
}

function SumAllusers(){
	
	$myfile = fopen('ChatID.txt', 'r');
	$sum = 0;
	
	while (!feof($myfile)) {
		$contents = fgets($myfile, 20);
		$sum += 1;
	}
	fclose($myfile);
	
	
	return $sum;
}

function MAKE() {
	$myfile = fopen('ChatID.txt', 'r');
	
	// $text = "All Users Links:";
	// $sum = 0;
	while (!feof($myfile)) {
		// $sum++;
		$contents = fgets($myfile, 20);
		// $text = $text."\n".$sum."- tg-user://".$contents." ";

		// if ($sum % 100 == 0) {
			// $postData = array (
				// 'chat_id' => 79612226,
				// 'text' => $text
			// );
			// makehttpreqeust('sendMessage',$postData);
			
			 // $text = "";
		// }
				chdir("AllUsers");

		// unlink(substr($contents,0,-1).".txt");
		$myfiler = fopen(substr($contents,0,-1).".txt", 'a+');
		
		fwrite($myfiler,$contents);
		fwrite($myfiler,"עברית");
		fclose($myfiler);
	
	}
	fclose($myfile);
				// $postData = array (
				// 'chat_id' => 79612226,
				// 'text' => $text
			// );
			// makehttpreqeust('sendMessage',$postData);
}

function CreatNewUser($UserId) {
	
	if (CheckId($UserId)) {
		
		// Add the user do the Big file.
		WriteChatID($UserId);
		
		$cd = getcwd();
		// Add user file private
		chdir("AllUsers");
		
		$myfile = fopen($UserId.".txt", 'a+');
		fwrite($myfile, $UserId);
		fwrite($myfile,"עברית");
		fclose($myfile);
		
		chdir($cd);	
		
		return true;
	} else {
		return false;
	}
}

function GetLang($UserId){
	
	$cd = getcwd();

	chdir("AllUsers");
		
	$myfile = fopen($UserId.".txt", 'r');
		
	$lang = fgets($myfile, 20);
	$lang = fgets($myfile, 20);
	
	fclose($myfile);
	
	chdir($cd);		

	return $lang;
}

function ChangeLang($UserId, $lnag) {
	
		$cd = getcwd();

		// Add user file private
		chdir("AllUsers");
		
		unlink($UserId.".txt");

		$myfile = fopen($UserId.".txt", 'a+');
		fwrite($myfile, $UserId);
		fwrite($myfile, "\n");
		fwrite($myfile, $lnag);
		fclose($myfile);
		chdir($cd);		
}

function sendDocument($chat_id, $document, $caption) 
{
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . API_KEY . "/sendDocument?chat_id=" . $chat_id);
    curl_setopt($ch, CURLOPT_POST, TRUE);
  curl_setopt($ch, CURLOPT_POSTFIELDS, array('document' => "@".$document, 'caption' => $caption));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:multipart/form-data']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
  $send = curl_exec($ch);
           // WriteToFile($send);

//    $j = json_decode($send, true);
//    if($j)
//    {    
//        WriteToFile($send);
//    }    
//    else
//    {
//        echo $send;
//    }
}

function GetLastUpdate($id)
{
    $url = "https://api.pwrtelegram.xyz/getchat?chat_id=".$id;
    
    $ch = curl_init();  
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1L);

    $output=curl_exec($ch);
//    WriteToFile($output);
    curl_close($ch);
    return json_decode($output,TRUE);

}
?>